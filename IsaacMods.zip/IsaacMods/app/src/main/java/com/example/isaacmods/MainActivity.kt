package com.example.isaacmods

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.geometry.Size
import java.net.HttpURLConnection
import java.util.zip.ZipInputStream
import kotlinx.coroutines.launch
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Данные (пока тестовые, потом приходят с сервера) ----------
data class Mod(
    val id: Int,
    val name: String,
    val author: String,
    val description: String?,          // null = ИИ не нашёл точного описания, блок не показываем
    val tags: List<String>,
    val officialLatest: String?,       // последняя версия, если удалось узнать
    val foundVersions: List<String>,   // найденные версии, от новой к старой
    val source: String,
    val urls: Map<String, String> = emptyMap(),   // версия -> https-ссылка на zip
    val pageOnly: Boolean = false,      // файл качается только на сайте-источнике
    val keywords: List<String> = emptyList(),   // слова для ИИ-поиска
    val popularity: Int = 0,
    val updated: Long = 0
) {
    val best get() = foundVersions.first()
    val isOutdated get() = officialLatest != null && best != officialLatest
}


// ---------- Каталог: catalog.json из твоего репозитория GitHub ----------
// ЗАМЕНИ на свою ссылку (репозиторий должен быть публичным)
const val CATALOG_URL = "https://raw.githubusercontent.com/ВАШ_НИК/ВАШ_РЕПО/main/catalog.json"

fun compareVersions(a: String, b: String): Int {
    val x = a.split(".", "-").map { it.toIntOrNull() ?: 0 }
    val y = b.split(".", "-").map { it.toIntOrNull() ?: 0 }
    for (i in 0 until maxOf(x.size, y.size)) {
        val c = x.getOrElse(i) { 0 }.compareTo(y.getOrElse(i) { 0 })
        if (c != 0) return c
    }
    return 0
}

fun loadCatalog(): List<Mod> {
    val text = URL(CATALOG_URL).openStream().bufferedReader().use { it.readText() }
    val arr = JSONObject(text).getJSONArray("mods")
    return (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i)
        val vs = o.getJSONArray("versions")
        val pairs = (0 until vs.length()).map { j -> vs.getJSONObject(j).let { it.getString("version") to it.getString("url") } }
            .sortedWith(Comparator { a, b -> compareVersions(b.first, a.first) })
        val tg = o.optJSONArray("tags")
        if (pairs.isEmpty()) null else Mod(
            id = o.optInt("id", i),
            name = o.getString("name"),
            author = o.optString("author", "—"),
            description = if (o.isNull("description")) null else o.getString("description"),
            tags = if (tg == null) emptyList() else (0 until tg.length()).map { tg.getString(it).lowercase() },
            officialLatest = if (o.isNull("officialLatest")) null else o.getString("officialLatest"),
            foundVersions = pairs.map { it.first },
            source = o.optString("source", ""),
            urls = pairs.toMap(),
            pageOnly = o.optBoolean("pageOnly", false),
            keywords = o.optJSONArray("keywords")?.let { a -> (0 until a.length()).map { a.getString(it).lowercase() } } ?: emptyList(),
            popularity = o.optInt("popularity", 0),
            updated = o.optLong("updated", 0)
        )
    }
}

// ---------- Скачивание с проверкой: файл должен быть настоящим zip ----------
suspend fun downloadZip(ctx: Context, url: String, name: String): String = withContext(Dispatchers.IO) {
    val tmp = java.io.File(ctx.cacheDir, "dl.tmp")
    try {
        var u = url
        var conn: HttpURLConnection? = null
        for (i in 0 until 6) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) IsaacMods/0.1")
            c.connectTimeout = 20000; c.readTimeout = 60000
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: return@withContext "Ошибка: пустое перенаправление"
                c.disconnect()
                u = URL(URL(u), loc).toString()
                if (!u.startsWith("https://")) return@withContext "Ошибка: небезопасная ссылка"
                continue
            }
            if (code != 200) { c.disconnect(); return@withContext "Сайт не отдал файл (код $code)" }
            conn = c; break
        }
        val c = conn ?: return@withContext "Ошибка: слишком много перенаправлений"
        c.inputStream.use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
        c.disconnect()
        if (tmp.length() < 100) return@withContext "Сайт отдал пустой файл (${tmp.length()} Б)"
        val head = tmp.inputStream().use { it.read() to it.read() }
        if (head.first != 0x50 || head.second != 0x4B) return@withContext "Сайт отдал не zip, а страницу. Открой мод на сайте-источнике"
        var entries = 0
        ZipInputStream(tmp.inputStream().buffered()).use { z -> while (z.nextEntry != null) entries++ }
        if (entries == 0) return@withContext "Архив пустой: внутри нет файлов"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@withContext "Не удалось сохранить файл"
        ctx.contentResolver.openOutputStream(uri)!!.use { out -> tmp.inputStream().use { it.copyTo(out) } }
        "Готово: $name, файлов внутри: $entries, ${tmp.length() / 1024} КБ. Папка «Загрузки»"
    } catch (e: Exception) {
        "Ошибка скачивания: ${e.message}"
    } finally { tmp.delete() }
}

// ---------- «ИИ-поиск» (заглушка: потом заменить запросом к серверу/ИИ) ----------
fun score(m: Mod, tokens: List<String>): Int = tokens.fold(0) { acc, t ->
    acc + (if (m.name.lowercase().contains(t)) 3 else 0) +
        (if (m.tags.any { it.contains(t) }) 2 else 0) +
        (if (m.keywords.any { it.contains(t) || t.contains(it) }) 2 else 0) +
        (if (m.description?.lowercase()?.contains(t) == true) 1 else 0)
}

// ---------- Свой стиль: тёмный, «кровавый», рубленые рамки ----------
val Bg = Color(0xFFF2D2A9); val PanelC = Color(0xFFFFE8C8); val Edge = Color(0xFF2A1410)
val Accent = Color(0xFFD62828); val Ink = Color(0xFF2A1410); val Dim = Color(0xFF7A5A48); val Warn = Color(0xFFE07A00)
val Marker = FontFamily(Font(R.font.press_start_2p))
val Pixel = Marker

fun loadAsset(ctx: Context, name: String): ImageBitmap? = try {
    ctx.assets.open(name).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
} catch (e: Exception) { null }

@Composable
fun BloodLine() {
    Canvas(Modifier.fillMaxWidth().height(22.dp)) {
        val p = Path(); p.moveTo(0f, 4f)
        var x = 0f
        while (x < size.width) { p.lineTo(x, 4f + (if ((x / 24f).toInt() % 2 == 0) 2f else -2f)); x += 24f }
        drawPath(p, Accent, style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        for (f in listOf(0.12f, 0.37f, 0.58f, 0.83f)) {
            val dx = size.width * f
            drawLine(Accent, Offset(dx, 4f), Offset(dx, 12f + f * 10f), strokeWidth = 5f, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun SearchPill(q: String, onQ: (String) -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(Modifier.fillMaxWidth().height(48.dp).background(Color(0xFFE0B98A), shape).border(2.dp, Edge, shape).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(20.dp)) {
            drawCircle(Dim, radius = size.width * 0.35f, center = Offset(size.width * 0.4f, size.height * 0.4f), style = Stroke(3f))
            drawLine(Dim, Offset(size.width * 0.65f, size.height * 0.65f), Offset(size.width * 0.95f, size.height * 0.95f), strokeWidth = 4f, cap = StrokeCap.Round)
        }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text("Поиск модов…", color = Color(0xFF8A7761), fontFamily = Pixel, fontSize = 11.sp)
            BasicTextField(q, onQ, singleLine = true, textStyle = TextStyle(color = Ink, fontFamily = Pixel, fontSize = 11.sp),
                cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun Header(q: String, onQ: (String) -> Unit) {
    val ctx = LocalContext.current
    val art = remember { loadAsset(ctx, "header_art.png") }   // своя PNG-картинка (необязательно)
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Моды Isaac", color = Accent, fontFamily = Marker, fontSize = 22.sp)
            Spacer(Modifier.width(8.dp))
            Tear()
            Spacer(Modifier.weight(1f))
            if (art != null) Image(bitmap = art, contentDescription = null, modifier = Modifier.height(56.dp))
        }
        BloodLine()
        SearchPill(q, onQ)
    }
}

@Composable
fun Section(title: String, list: List<Mod>, onOpen: (Mod) -> Unit) {
    if (list.isEmpty()) return
    Column {
        Text(title, color = Accent, fontFamily = Marker, fontSize = 15.sp)
        Spacer(Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { Box(Modifier.width(240.dp)) { ModCard(it, onOpen) } }
        }
    }
}

// Сайты-партнёры: (название, домен для поиска, раздел Isaac на сайте)
val SITES = listOf(
    Triple("playground.ru", "playground.ru", "https://www.playground.ru/binding_of_isaac/file"),
    Triple("GameBanana", "gamebanana.com", "https://gamebanana.com/mods/games/13178"),
    Triple("smods.ru", "catalogue.smods.ru", "https://catalogue.smods.ru/game/the-binding-of-isaac-rebirth"),
    Triple("xmodhub", "xmodhub.com", "https://www.xmodhub.com/ru/game-mods/the-binding-of-isaac-repentance+-mods")
)

// Пиксельная рамка со срезанными углами и жёсткой тенью
fun Modifier.pixelBox(fill: Color = PanelC): Modifier = this.drawBehind {
    val u = 4.dp.toPx(); val w = size.width; val h = size.height
    drawRect(Color(0x66000000), Offset(u, u), Size(w, h))
    drawRect(Edge, Offset(u, 0f), Size(w - 2 * u, h)); drawRect(Edge, Offset(0f, u), Size(w, h - 2 * u))
    drawRect(fill, Offset(2 * u, u), Size(w - 4 * u, h - 2 * u)); drawRect(fill, Offset(u, 2 * u), Size(w - 2 * u, h - 4 * u))
}

// Кривой «нарисованный от руки» контур в два прохода
fun Modifier.sketch(width: Float = 6f): Modifier = this.drawBehind {
    val rnd = java.util.Random(size.width.toLong() * 31 + size.height.toLong())
    fun j() = (rnd.nextFloat() - 0.5f) * 6f
    for (pass in 0..1) {
        val p = Path()
        val step = 26f
        p.moveTo(j(), j())
        var x = step
        while (x < size.width) { p.lineTo(x, j()); x += step }
        p.lineTo(size.width + j(), j())
        var y = step
        while (y < size.height) { p.lineTo(size.width + j(), y); y += step }
        p.lineTo(size.width + j(), size.height + j())
        x = size.width - step
        while (x > 0f) { p.lineTo(x, size.height + j()); x -= step }
        p.lineTo(j(), size.height + j())
        y = size.height - step
        while (y > 0f) { p.lineTo(j(), y); y -= step }
        p.close()
        drawPath(p, Edge, style = Stroke(width = if (pass == 0) width else width / 2, join = StrokeJoin.Round, cap = StrokeCap.Round))
    }
}

@Composable
fun Tear() {
    Canvas(Modifier.size(22.dp, 30.dp)) {
        val w = size.width; val h = size.height
        val p = Path().apply {
            moveTo(w / 2, 2f)
            cubicTo(w, h * 0.55f, w * 0.95f, h - 2f, w / 2, h - 2f)
            cubicTo(w * 0.05f, h - 2f, 0f, h * 0.55f, w / 2, 2f)
            close()
        }
        drawPath(p, Color(0xFF4FA3F7))
        drawPath(p, Edge, style = Stroke(width = 4f, join = StrokeJoin.Round))
    }
}
val Blocky = RoundedCornerShape(2.dp)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Bg, surface = PanelC, onSurface = Ink, onBackground = Ink)) {
        var open by remember { mutableStateOf<Mod?>(null) }
        var mods by remember { mutableStateOf(emptyList<Mod>()) }
        var status by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(Unit) {
            try { mods = withContext(Dispatchers.IO) { loadCatalog() }; if (mods.isEmpty()) status = "Каталог пока пуст" }
            catch (e: Exception) { status = "Каталог не загрузился. Проверь интернет" }
        }
        BackHandler(enabled = open != null) { open = null }
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Box(Modifier.fillMaxSize().drawBehind {
                drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0x66301810)), center = center, radius = size.maxDimension * 0.8f))
            }) {
                val m = open
                if (m == null) Catalog(mods, status) { open = it } else Detail(m) { open = null }
            }
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    var mod = modifier.fillMaxWidth().padding(end = 4.dp, bottom = 4.dp).pixelBox()
    if (onClick != null) mod = mod.clickable(onClick = onClick)
    Column(mod.padding(14.dp), content = content)
}

@Composable
fun PixelButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.fillMaxWidth(), shape = Blocky, border = BorderStroke(3.dp, Edge), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = PanelC)) {
        Text(text, fontFamily = Pixel, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ModCard(m: Mod, onOpen: (Mod) -> Unit) {
    Panel(onClick = { onOpen(m) }) {
        Text(m.name, color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text("${m.author} · v${m.best}", color = Dim, fontFamily = Pixel, fontSize = 9.sp)
        Text(m.tags.joinToString(" · "), color = Dim, fontFamily = Pixel, fontSize = 9.sp)
        if (m.isOutdated) Text("⚠ не последняя версия", color = Warn, fontFamily = Pixel, fontSize = 9.sp)
    }
}

@Composable
fun Catalog(mods: List<Mod>, status: String?, onOpen: (Mod) -> Unit) {
    var q by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val popular = remember(mods) { mods.filter { it.popularity > 0 }.sortedByDescending { it.popularity }.take(10) }
    val fresh = remember(mods) { mods.filter { it.updated > 0 }.sortedByDescending { it.updated }.take(10) }
    val picks = remember(mods) { mods.filter { it.description != null }.shuffled(java.util.Random(java.time.LocalDate.now().toEpochDay())).take(10) }
    val tokens = q.lowercase().split(" ").filter { it.length > 1 }
    val found = if (tokens.isEmpty()) mods
        else mods.map { it to score(it, tokens) }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
    val similar = if (tokens.isEmpty() || found.isEmpty()) emptyList()
        else mods.filter { m -> m !in found && m.tags.any { it in found.first().tags } }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Header(q) { q = it }
            if (status != null) Text(status, color = Warn, fontFamily = Pixel, fontSize = 9.sp)
            Text("Модов в каталоге: ${mods.size}", color = Dim, fontFamily = Pixel, fontSize = 9.sp)
        }
        if (tokens.isEmpty()) {
            item { Section("Популярное", popular, onOpen) }
            item { Section("Недавно обновлено", fresh, onOpen) }
            item { Section("Рекомендуем сегодня", picks, onOpen) }
            item { Text("Все моды", color = Accent, fontFamily = Marker, fontSize = 15.sp) }
        }
        item {
            Panel {
                Text("Искать на других сайтах", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                SITES.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (label, domain, section) ->
                            PixelButton(label, Modifier.weight(1f)) {
                                val url = if (tokens.isEmpty()) section
                                    else "https://www.google.com/search?q=" + URLEncoder.encode("site:$domain isaac $q", "UTF-8")
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            }
                        }
                    }
                }
            }
        }
        items(found) { ModCard(it, onOpen) }
        if (tokens.isNotEmpty() && found.isEmpty()) item { Text("Ничего не нашлось", color = Dim, fontFamily = Pixel) }
        if (similar.isNotEmpty()) {
            item { Text("Похожие моды", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold) }
            items(similar) { ModCard(it, onOpen) }
        }
    }
}

@Composable
fun Detail(m: Mod, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var showOthers by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun download(v: String) {
        val url = m.urls[v]
        if (m.pageOnly && url != null) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); return }
        if (url == null || !url.startsWith("https://")) {
            Toast.makeText(ctx, "Для этой версии нет https-ссылки", Toast.LENGTH_SHORT).show(); return
        }
        val file = m.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_") + "_v$v.zip"
        Toast.makeText(ctx, "Скачиваю…", Toast.LENGTH_SHORT).show()
        scope.launch { Toast.makeText(ctx, downloadZip(ctx, url, file), Toast.LENGTH_LONG).show() }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TextButton(onBack) { Text("← Назад", color = Dim, fontFamily = Pixel) }
        Text(m.name, color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text("${m.author} · версия ${m.best} · источник: ${m.source}", color = Dim, fontFamily = Pixel, fontSize = 9.sp)
        if (m.isOutdated) Panel {
            Text("⚠ Это не последняя версия. Последняя: ${m.officialLatest}, но её найти не удалось. Показана максимальная найденная.",
                color = Warn, fontFamily = Pixel, fontSize = 10.sp)
        }
        m.description?.let { Panel { Text(it, color = Ink, fontFamily = Pixel, fontSize = 10.sp) } }
        PixelButton(if (m.pageOnly) "Скачать на сайте-источнике" else "Скачать v${m.best}") { download(m.best) }

        // Плашка внизу: другие версии
        if (!m.pageOnly) Panel(onClick = { showOthers = !showOthers }) {
            Text(if (showOthers) "Скрыть другие версии ▲" else "Скачать другие версии ▼", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold)
        }
        if (showOthers) m.foundVersions.forEach { v ->
            PixelButton("v$v" + if (v == m.best) " (актуальная из найденных)" else "") { download(v) }
        }
    }
}
