package com.example.isaacmods

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import coil.decode.ImageDecoderDecoder
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.FilterQuality
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.zip.ZipInputStream

// ================= Данные =================
data class Mod(
    val id: Int,
    val name: String,
    val author: String,
    val description: String?,
    val tags: List<String>,
    val officialLatest: String?,
    val foundVersions: List<String>,   // от новой к старой
    val source: String,
    val urls: Map<String, String> = emptyMap(),
    val pageOnly: Boolean = false,
    val keywords: List<String> = emptyList(),
    val popularity: Int = 0,
    val updated: Long = 0,
    val icon: String? = null
) {
    val best get() = foundVersions.first()
    val isOutdated get() = officialLatest != null && best != officialLatest
}

// ЗАМЕНИТСЯ при сборке на ссылку на твой репозиторий
const val CATALOG_URL = "https://raw.githubusercontent.com/ВАШ_НИК/ВАШ_РЕПО/main/catalog.json"
val BASE_URL get() = CATALOG_URL.substringBeforeLast("/") + "/"
fun iconUrl(m: Mod): String? = m.icon?.let { if (it.startsWith("http")) it else BASE_URL + it }

fun compareVersions(a: String, b: String): Int {
    val x = a.split(".", "-").map { it.toIntOrNull() ?: 0 }
    val y = b.split(".", "-").map { it.toIntOrNull() ?: 0 }
    for (i in 0 until maxOf(x.size, y.size)) {
        val c = x.getOrElse(i) { 0 }.compareTo(y.getOrElse(i) { 0 })
        if (c != 0) return c
    }
    return 0
}

fun loadCatalog(): List<Mod> {
    val text = URL(CATALOG_URL).openStream().bufferedReader().use { it.readText() }
    val arr = JSONObject(text).getJSONArray("mods")
    return (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i)
        val vs = o.getJSONArray("versions")
        val pairs = (0 until vs.length()).map { j -> vs.getJSONObject(j).let { it.getString("version") to it.getString("url") } }
            .sortedWith(Comparator { a, b -> compareVersions(b.first, a.first) })
        val tg = o.optJSONArray("tags")
        if (pairs.isEmpty()) null else Mod(
            id = o.optInt("id", i),
            name = o.getString("name"),
            author = o.optString("author", "—"),
            description = if (o.isNull("description")) null else o.getString("description"),
            tags = if (tg == null) emptyList() else (0 until tg.length()).map { tg.getString(it).lowercase() },
            officialLatest = if (o.isNull("officialLatest")) null else o.getString("officialLatest"),
            foundVersions = pairs.map { it.first },
            source = o.optString("source", ""),
            urls = pairs.toMap(),
            pageOnly = o.optBoolean("pageOnly", false),
            keywords = o.optJSONArray("keywords")?.let { a -> (0 until a.length()).map { a.getString(it).lowercase() } } ?: emptyList(),
            popularity = o.optInt("popularity", 0),
            updated = o.optLong("updated", 0),
            icon = if (o.isNull("icon")) null else o.optString("icon").ifBlank { null }
        )
    }
}

// ================= Собственный загрузчик =================
class DlItem(val title: String) {
    var progress by mutableStateOf(0f)
    var status by mutableStateOf("Ожидание…")
    var finished by mutableStateOf(false)
    var failed by mutableStateOf(false)
}

object Downloader {
    val items = mutableStateListOf<DlItem>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun start(ctx: Context, title: String, url: String, fileName: String) {
        val app = ctx.applicationContext
        val item = DlItem(title)
        items.add(0, item)
        scope.launch { run(app, item, url, fileName) }
    }

    private fun fail(item: DlItem, msg: String) { item.failed = true; item.finished = true; item.status = msg }

    private fun run(ctx: Context, item: DlItem, url: String, name: String) {
        val tmp = File(ctx.cacheDir, "dl_${System.nanoTime()}.tmp")
        try {
            item.status = "Подключение…"
            var u = url
            var conn: HttpURLConnection? = null
            for (i in 0 until 8) {
                val c = URL(u).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) IsaacMods/0.2")
                c.setRequestProperty("Accept", "*/*")
                c.connectTimeout = 20000; c.readTimeout = 60000
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return fail(item, "Пустое перенаправление")
                    c.disconnect()
                    u = URL(URL(u), loc).toString()
                    if (!u.startsWith("https://")) return fail(item, "Небезопасная ссылка")
                    continue
                }
                if (code != 200) { c.disconnect(); return fail(item, "Сайт не отдал файл (код $code)") }
                conn = c; break
            }
            val c = conn ?: return fail(item, "Слишком много перенаправлений")
            val total = c.contentLengthLong
            item.status = "Скачивание…"
            c.inputStream.use { inp ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n); done += n
                        if (total > 0) item.progress = done.toFloat() / total
                    }
                }
            }
            c.disconnect()
            item.status = "Проверка файла…"
            if (tmp.length() < 100) return fail(item, "Сайт отдал пустой файл (${tmp.length()} Б)")
            val head = tmp.inputStream().use { it.read() to it.read() }
            if (head.first != 0x50 || head.second != 0x4B) return fail(item, "Сайт отдал не zip, а страницу")
            var entries = 0
            ZipInputStream(tmp.inputStream().buffered()).use { z -> while (z.nextEntry != null) entries++ }
            if (entries == 0) return fail(item, "Архив пустой: внутри нет файлов")
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/IsaacMods")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return fail(item, "Не удалось сохранить файл")
            ctx.contentResolver.openOutputStream(uri)!!.use { out -> tmp.inputStream().use { it.copyTo(out) } }
            item.progress = 1f
            item.finished = true
            item.status = "Готово: файлов внутри $entries, ${tmp.length() / 1024} КБ. Папка «Загрузки/IsaacMods»"
        } catch (e: Exception) {
            fail(item, "Ошибка: ${e.message}")
        } finally { tmp.delete() }
    }
}

// ================= Поиск =================
fun score(m: Mod, tokens: List<String>): Int = tokens.fold(0) { acc, t ->
    acc + (if (m.name.lowercase().contains(t)) 3 else 0) +
        (if (m.tags.any { it.contains(t) }) 2 else 0) +
        (if (m.keywords.any { it.contains(t) || t.contains(it) }) 2 else 0) +
        (if (m.description?.lowercase()?.contains(t) == true) 1 else 0)
}

val SITES = listOf(
    Triple("playground.ru", "playground.ru", "https://www.playground.ru/binding_of_isaac/file"),
    Triple("GameBanana", "gamebanana.com", "https://gamebanana.com/mods/games/13178"),
    Triple("smods.ru", "catalogue.smods.ru", "https://catalogue.smods.ru/game/the-binding-of-isaac-rebirth"),
    Triple("xmodhub", "xmodhub.com", "https://www.xmodhub.com/ru/game-mods/the-binding-of-isaac-repentance+-mods"),
    Triple("Гид-вики", "moddingofisaac.wiki.gg", "https://moddingofisaac.wiki.gg/")
)

fun openUrl(ctx: Context, url: String) = ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
fun openSearch(ctx: Context, site: String, q: String) =
    openUrl(ctx, "https://www.google.com/search?q=" + URLEncoder.encode("site:$site $q", "UTF-8"))

// ================= Стиль: тёмный подвал + пергамент =================
val PanelC = Color(0xFFD6C3A5); val Edge = Color(0xFF080201)
val Accent = Color(0xFFB5070A); val Ink = Color(0xFF2A1210); val Dim = Color(0xFF6B4B44); val Warn = Color(0xFF9A4A00)
val Light = Color(0xFFD9C7AA); val DimLight = Color(0xFFA48C79); val RedLight = Color(0xFFE02A2A)
val Marker = FontFamily(Font(R.font.press_start_2p))   // единственный открытый пиксельный шрифт с кириллицей
val Pixel = Marker
val Blocky = RoundedCornerShape(2.dp)

fun DrawScope.drawBasement() {
    drawRect(Color(0xFF170504))
    val bw = 64.dp.toPx(); val bh = 30.dp.toPx()
    var y = 0f; var row = 0
    while (y < size.height) {
        var x = if (row % 2 == 0) 0f else -bw / 2
        while (x < size.width) {
            val shade = if ((row + (x / bw).toInt()) % 3 == 0) 0xFF2C0A0B else 0xFF210C0C
            drawRect(Color(shade), Offset(x + 2f, y + 2f), Size(bw - 4f, bh - 4f))
            x += bw
        }
        y += bh; row++
    }
    drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0xCC080201)), center = center, radius = size.maxDimension * 0.75f))
    drawRect(Color(0xFFB3080C), Offset(10f, 10f), Size(size.width - 20f, size.height - 20f), style = Stroke(6f))
    drawRect(Color(0x66E02A2A), Offset(18f, 18f), Size(size.width - 36f, size.height - 36f), style = Stroke(2f))
}

fun Modifier.pixelBox(fill: Color = PanelC): Modifier = this.drawBehind {
    val u = 4.dp.toPx(); val w = size.width; val h = size.height
    drawRect(Color(0x66000000), Offset(u, u), Size(w, h))
    drawRect(Edge, Offset(u, 0f), Size(w - 2 * u, h)); drawRect(Edge, Offset(0f, u), Size(w, h - 2 * u))
    drawRect(fill, Offset(2 * u, u), Size(w - 4 * u, h - 2 * u)); drawRect(fill, Offset(u, 2 * u), Size(w - 2 * u, h - 4 * u))
    // светлая фаска сверху-слева
    drawRect(Color(0x55FFFFFF), Offset(2 * u, u), Size(w - 4 * u, u / 2))
    // тёмная «дизерная» полоса снизу
    var x = 2 * u; var k = 0
    while (x < w - 2 * u) {
        drawRect(Color(0x33000000), Offset(x, h - 2 * u - (if (k % 2 == 0) u / 2 else 0f)), Size(u / 2, u / 2))
        drawRect(Color(0x22000000), Offset(x, h - 2 * u), Size(u / 2, u / 2))
        x += u / 2; k++
    }
}

@Composable
fun PixelSprite(rows: List<String>, palette: Map<Char, Color>, px: Dp = 4.dp) {
    val w = rows.maxOf { it.length }
    Canvas(Modifier.size(px * w, px * rows.size)) {
        val u = px.toPx()
        rows.forEachIndexed { y, r -> r.forEachIndexed { x, ch -> palette[ch]?.let { drawRect(it, Offset(x * u, y * u), Size(u, u)) } } }
    }
}

val HEART = listOf(
    ".ooo...ooo.", "orrrooorrro", "orwrrrrrrro", "orrrrrrrrro", "orrrrrrrrro",
    ".orrrrrrro.", "..orrrrro..", "...orrro...", "....oro....", ".....o....."
)
val HEART_PAL = mapOf('o' to Color(0xFF140A0A), 'r' to Color(0xFFE02A2A), 'w' to Color(0xFFFFB0B0))
val GEAR = listOf(
    ".......ooooo.......",
    ".....oowwwwwoo.....",
    "....owowwwwwogo....",
    "...owwoowwwooggo...",
    "..owwwwwwwwgggggo..",
    ".owwwwwwwwwggggggo.",
    ".ooowwwwwwwggggooo.",
    "owwowwwwooogggdoddo",
    "owwwwwwo...oddddddo",
    "owwwwwwo...oddddddo",
    "owwwwwwo...oddddddo",
    "owwoggggoooddddoddo",
    ".oooggggdddddddooo.",
    ".oggggggdddddddddo.",
    "..oggggdddddddddo..",
    "...oggoodddooddo...",
    "....ogodddddodo....",
    ".....oodddddoo.....",
    ".......ooooo......."
)
val GEAR_PAL = mapOf('o' to Color(0xFF140A0A), 'g' to Color(0xFFB8B8C4), 'd' to Color(0xFF70707C), 'w' to Color(0xFFEDEDF5))

val COIN = listOf("..ooo..", ".oyyyo.", "oyywyyo", "oyywyyo", "oyyyyyo", ".oyyyo.", "..ooo..")
val COIN_PAL = mapOf('o' to Color(0xFF140A0A), 'y' to Color(0xFFF2C230), 'w' to Color(0xFFFFF0A0))
val BOMB = listOf(".....o.y.", "....oo...", "..ooooo..", ".obbbbbo.", "obwbbbbbo", "obbbbbbbo", "obbbbbbbo", ".obbbbbo.", "..ooooo..")
val BOMB_PAL = mapOf('o' to Color(0xFF140A0A), 'b' to Color(0xFF4A4A55), 'w' to Color(0xFFA0A0B0), 'y' to Color(0xFFFFB030))
val KEY = listOf(".ooo.", "oyyyo", "oy.yo", "oyyyo", ".oyo.", ".oyo.", ".oyyo", ".oyo.", ".oyyo", ".ooo.")
val KEY_PAL = mapOf('o' to Color(0xFF140A0A), 'y' to Color(0xFFE8C040))

@Composable fun Heart(px: Dp = 3.dp) = PixelSprite(HEART, HEART_PAL, px)

@Composable
fun HudStat(rows: List<String>, pal: Map<Char, Color>, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        PixelSprite(rows, pal, 3.dp)
        Spacer(Modifier.width(4.dp))
        Text("x$value", color = Light, fontFamily = Pixel, fontSize = 9.sp)
    }
}

@Composable
fun Hud(mods: List<Mod>) {
    val weekAgo = System.currentTimeMillis() / 1000 - 7 * 86400
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(1f, 1.18f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "h")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.graphicsLayer(scaleX = pulse, scaleY = pulse)) { Heart(2.dp); Heart(2.dp); Heart(2.dp) }
        HudStat(COIN, COIN_PAL, "${mods.size}")
        HudStat(BOMB, BOMB_PAL, "${Downloader.items.count { it.finished && !it.failed }}")
        HudStat(KEY, KEY_PAL, "${mods.count { it.updated > weekAgo }}")
    }
}

@Composable
fun IsaacGif(size: Dp) {
    val ctx = LocalContext.current
    val loader = remember { ImageLoader.Builder(ctx).components { add(ImageDecoderDecoder.Factory()) }.build() }
    AsyncImage(model = "file:///android_asset/isaac.gif", imageLoader = loader, contentDescription = null,
        filterQuality = FilterQuality.None, modifier = Modifier.size(size))
}

@Composable
fun Tear() {
    Canvas(Modifier.size(22.dp, 30.dp)) {
        val w = size.width; val h = size.height
        val p = Path().apply {
            moveTo(w / 2, 2f)
            cubicTo(w, h * 0.55f, w * 0.95f, h - 2f, w / 2, h - 2f)
            cubicTo(w * 0.05f, h - 2f, 0f, h * 0.55f, w / 2, 2f)
            close()
        }
        drawPath(p, Color(0xFF4FA3F7))
        drawPath(p, Edge, style = Stroke(width = 4f, join = StrokeJoin.Round))
    }
}

@Composable
fun OutlinedTitle(text: String, size: TextUnit) {
    Box {
        Text(text, fontFamily = Marker, fontSize = size, color = Color.Black, style = TextStyle(drawStyle = Stroke(width = 14f, join = StrokeJoin.Round)))
        Text(text, fontFamily = Marker, fontSize = size, color = Color(0xFFE01818))
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    var mod = modifier.fillMaxWidth().padding(end = 4.dp, bottom = 4.dp).pixelBox()
    if (onClick != null) mod = mod.clickable(onClick = onClick)
    Column(mod.padding(14.dp), content = content)
}

@Composable
fun PixelButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxWidth().padding(end = 4.dp, bottom = 4.dp).pixelBox(Accent).clickable(onClick = onClick)
        .padding(vertical = 14.dp, horizontal = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = PanelC, fontFamily = Pixel, fontSize = 10.sp)
    }
}

@Composable
fun ModIcon(m: Mod, size: Dp) {
    val url = iconUrl(m)
    Box(Modifier.size(size).padding(end = 4.dp, bottom = 4.dp).pixelBox(Color(0xFF3A1A1D)).padding(6.dp), contentAlignment = Alignment.Center) {
        val placeholder: @Composable () -> Unit = { PixelSprite(GEAR, GEAR_PAL, px = (size.value / 28f).dp) }
        if (url == null) placeholder()
        else SubcomposeAsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(), loading = { placeholder() }, error = { placeholder() })
    }
}

fun loadAsset(ctx: Context, name: String): ImageBitmap? = try {
    ctx.assets.open(name).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
} catch (e: Exception) { null }

// ================= Перевод описаний на русский (на устройстве) =================
fun hasCyrillic(s: String) = s.any { it in 'А'..'я' || it == 'ё' || it == 'Ё' }
fun mostlyCjk(s: String) = s.count { it.code > 0x2E80 } > s.length / 4

@Composable
fun Description(text: String) {
    var shown by remember(text) { mutableStateOf(text) }
    var state by remember(text) { mutableStateOf(if (hasCyrillic(text) || mostlyCjk(text)) "ready" else "loading") }
    LaunchedEffect(text) {
        if (state == "loading") {
            val tr = Translation.getClient(TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.RUSSIAN).build())
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    tr.translate(text).addOnSuccessListener { shown = it; state = "translated" }.addOnFailureListener { state = "ready" }
                }
                .addOnFailureListener { state = "ready" }
        }
    }
    Text(shown, color = Ink, fontFamily = FontFamily.SansSerif, fontSize = 15.sp, lineHeight = 22.sp)
    if (state == "loading") Text("Перевожу на русский… (при первом запуске загружается языковой пакет)", color = Dim, fontFamily = Pixel, fontSize = 8.sp)
    if (state == "translated") Text("Переведено автоматически", color = Dim, fontFamily = Pixel, fontSize = 8.sp)
}

// ================= Экраны =================
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Color(0xFF170504), surface = PanelC, onSurface = Ink, onBackground = Light)) {
        var open by remember { mutableStateOf<Mod?>(null) }
        var mods by remember { mutableStateOf(emptyList<Mod>()) }
        var status by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(Unit) {
            try { mods = withContext(Dispatchers.IO) { loadCatalog() }; if (mods.isEmpty()) status = "Каталог пока пуст" }
            catch (e: Exception) { status = "Каталог не загрузился. Проверь интернет" }
        }
        BackHandler(enabled = open != null) { open = null }
        Surface(Modifier.fillMaxSize(), color = Color(0xFF170504)) {
            Box(Modifier.fillMaxSize().drawBehind { drawBasement() }) {
                val m = open
                if (m == null) Catalog(mods, status) { open = it } else Detail(m) { open = null }
            }
        }
    }
}

@Composable
fun BloodLine() {
    Canvas(Modifier.fillMaxWidth().height(22.dp)) {
        val p = Path(); p.moveTo(0f, 4f)
        var x = 0f
        while (x < size.width) { p.lineTo(x, 4f + (if ((x / 24f).toInt() % 2 == 0) 2f else -2f)); x += 24f }
        drawPath(p, Color(0xFFD62828), style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        for (f in listOf(0.12f, 0.37f, 0.58f, 0.83f)) {
            val dx = size.width * f
            drawLine(Color(0xFFD62828), Offset(dx, 4f), Offset(dx, 12f + f * 10f), strokeWidth = 5f, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun SearchPill(q: String, onQ: (String) -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(Modifier.fillMaxWidth().height(50.dp).background(Color(0xFF4A2A2B), shape).border(2.dp, Color(0xFF8B3A3A), shape).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(20.dp)) {
            drawCircle(DimLight, radius = size.width * 0.35f, center = Offset(size.width * 0.4f, size.height * 0.4f), style = Stroke(3f))
            drawLine(DimLight, Offset(size.width * 0.65f, size.height * 0.65f), Offset(size.width * 0.95f, size.height * 0.95f), strokeWidth = 4f, cap = StrokeCap.Round)
        }
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text("Поиск модов…", color = Color(0xFFA89484), fontFamily = Pixel, fontSize = 10.sp)
            BasicTextField(q, onQ, singleLine = true, textStyle = TextStyle(color = Light, fontFamily = Pixel, fontSize = 11.sp),
                cursorBrush = SolidColor(RedLight), modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun Header(q: String, onQ: (String) -> Unit) {
    val ctx = LocalContext.current
    val art = remember { loadAsset(ctx, "header_art.png") }   // своя PNG-картинка (необязательно)
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTitle("TBOI MODS", 18.sp)
            Spacer(Modifier.weight(1f))
            if (art != null) Image(bitmap = art, contentDescription = null, modifier = Modifier.height(64.dp), filterQuality = FilterQuality.None)
            else IsaacGif(64.dp)
        }
        Text("The Binding of Isaac: Repentance Mods", color = DimLight, fontFamily = Pixel, fontSize = 7.sp)
        BloodLine()
        SearchPill(q, onQ)
    }
}

@Composable
fun SectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Heart(2.dp); Spacer(Modifier.width(8.dp))
        Text(text, color = RedLight, fontFamily = Marker, fontSize = 13.sp)
    }
}

@Composable
fun ModCard(m: Mod, onOpen: (Mod) -> Unit) {
    Panel(onClick = { onOpen(m) }) {
        Row {
            ModIcon(m, 84.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(m.name, color = Ink, fontFamily = Pixel, fontSize = 10.sp, maxLines = 2, lineHeight = 15.sp)
                Spacer(Modifier.height(3.dp))
                Text("${m.author} · v${m.best}", color = Dim, fontFamily = Pixel, fontSize = 7.sp, maxLines = 1)
                m.description?.let {
                    Spacer(Modifier.height(5.dp))
                    Text(it, color = Ink, fontFamily = FontFamily.SansSerif, fontSize = 13.sp, lineHeight = 17.sp, maxLines = 2)
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(m.source, color = PanelC, fontFamily = Pixel, fontSize = 6.sp,
                        modifier = Modifier.background(Dim).padding(horizontal = 5.dp, vertical = 3.dp))
                    if (m.isOutdated) Text("не последняя", color = PanelC, fontFamily = Pixel, fontSize = 6.sp,
                        modifier = Modifier.background(Warn).padding(horizontal = 5.dp, vertical = 3.dp))
                }
            }
        }
    }
}

@Composable
fun Section(title: String, list: List<Mod>, onOpen: (Mod) -> Unit) {
    if (list.isEmpty()) return
    Column {
        SectionTitle(title)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { Box(Modifier.width(280.dp)) { ModCard(it, onOpen) } }
        }
    }
}

@Composable
fun DownloadsPanel() {
    if (Downloader.items.isEmpty()) return
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (Downloader.items.any { !it.finished }) { IsaacGif(36.dp); Spacer(Modifier.width(8.dp)) }
            Text("Загрузки", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
        Downloader.items.take(4).forEach { it ->
            Spacer(Modifier.height(8.dp))
            Text(it.title, color = Ink, fontFamily = Pixel, fontSize = 8.sp, maxLines = 1)
            if (!it.finished) LinearProgressIndicator(progress = { it.progress }, Modifier.fillMaxWidth().height(8.dp), color = Accent, trackColor = Color(0xFFB5A085))
            Text(it.status, color = if (it.failed) Accent else Dim, fontFamily = FontFamily.SansSerif, fontSize = 13.sp)
        }
    }
}

@Composable
fun Catalog(mods: List<Mod>, status: String?, onOpen: (Mod) -> Unit) {
    var q by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val popular = remember(mods) { mods.filter { it.popularity > 0 }.sortedByDescending { it.popularity }.take(10) }
    val fresh = remember(mods) { mods.filter { it.updated > 0 }.sortedByDescending { it.updated }.take(10) }
    val picks = remember(mods) { mods.filter { it.description != null }.shuffled(java.util.Random(java.time.LocalDate.now().toEpochDay())).take(10) }
    val tokens = q.lowercase().split(" ").filter { it.length > 1 }
    val found = if (tokens.isEmpty()) mods
        else mods.map { it to score(it, tokens) }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
    val similar = if (tokens.isEmpty() || found.isEmpty()) emptyList()
        else mods.filter { m -> m !in found && m.tags.any { it in found.first().tags } }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Header(q) { q = it } }
        item {
            if (status != null) Text(status, color = Color(0xFFFFB35C), fontFamily = Pixel, fontSize = 9.sp)
            Hud(mods)
            Text("монеты: модов · бомбы: загружено · ключи: обновлено за неделю", color = DimLight, fontFamily = Pixel, fontSize = 6.sp)
        }
        if (mods.isEmpty() && status == null) item {
            Panel { Row(verticalAlignment = Alignment.CenterVertically) {
                IsaacGif(56.dp); Spacer(Modifier.width(10.dp))
                Text("Загружаю моды из подвала…", color = Ink, fontFamily = Pixel, fontSize = 10.sp)
            } }
        }
        if (Downloader.items.isNotEmpty()) item { DownloadsPanel() }
        if (tokens.isEmpty()) {
            item { Section("Популярное", popular, onOpen) }
            item { Section("Недавно обновлено", fresh, onOpen) }
            item { Section("Рекомендуем сегодня", picks, onOpen) }
        }
        item {
            Panel {
                Text("Искать на других сайтах", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                SITES.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (label, domain, section) ->
                            PixelButton(label, Modifier.weight(1f)) {
                                openUrl(ctx, if (tokens.isEmpty()) section
                                    else "https://www.google.com/search?q=" + URLEncoder.encode("site:$domain isaac $q", "UTF-8"))
                            }
                        }
                    }
                }
            }
        }
        if (tokens.isEmpty()) item { SectionTitle("Все моды") }
        if (tokens.isNotEmpty() && found.isEmpty()) item {
            Panel { Row(verticalAlignment = Alignment.CenterVertically) {
                IsaacGif(56.dp); Spacer(Modifier.width(10.dp))
                Text("Ничего не нашлось", color = Ink, fontFamily = Pixel, fontSize = 10.sp)
            } }
        }
        items(found) { ModCard(it, onOpen) }
        if (similar.isNotEmpty()) {
            item { SectionTitle("Похожие моды") }
            items(similar) { ModCard(it, onOpen) }
        }
    }
}

@Composable
fun Detail(m: Mod, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var showOthers by remember { mutableStateOf(false) }
    fun download(v: String) {
        val url = m.urls[v]
        if (url == null || !url.startsWith("https://")) {
            Toast.makeText(ctx, "Для этой версии нет https-ссылки", Toast.LENGTH_SHORT).show(); return
        }
        if (m.pageOnly) { openUrl(ctx, url); return }
        val file = m.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_") + "_v$v.zip"
        Downloader.start(ctx, "${m.name} v$v", url, file)
        Toast.makeText(ctx, "Загрузка началась, смотри блок «Загрузки»", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onBack) { Text("← Назад", color = Light, fontFamily = Pixel, fontSize = 10.sp) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            ModIcon(m, 96.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(m.name, color = Light, fontFamily = Marker, fontSize = 14.sp)
                Spacer(Modifier.height(4.dp))
                Text("${m.author} · версия ${m.best}", color = DimLight, fontFamily = Pixel, fontSize = 8.sp)
                Text("источник: ${m.source}", color = DimLight, fontFamily = Pixel, fontSize = 8.sp)
            }
        }
        if (m.isOutdated) Panel {
            Text("⚠ Это не последняя версия. Последняя: ${m.officialLatest}, но её найти не удалось. Показана максимальная найденная.",
                color = Warn, fontFamily = Pixel, fontSize = 9.sp)
        }
        m.description?.let { Panel { Description(it) } }
        PixelButton(if (m.pageOnly) "Скачать на сайте-источнике" else "Скачать v${m.best}") { download(m.best) }
        DownloadsPanel()
        Panel {
            Text("Узнать больше об этом моде", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
            PixelButton("1. Гид по модам (вики)") { openSearch(ctx, "moddingofisaac.wiki.gg", m.name) }
            Spacer(Modifier.height(6.dp))
            PixelButton("2. Файлы на playground.ru") { openSearch(ctx, "playground.ru/binding_of_isaac", m.name + " repentance") }
        }
        if (!m.pageOnly) Panel(onClick = { showOthers = !showOthers }) {
            Text(if (showOthers) "Скрыть другие версии ▲" else "Скачать другие версии ▼", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 10.sp)
        }
        if (showOthers) m.foundVersions.forEach { v ->
            PixelButton("v$v" + if (v == m.best) " (актуальная из найденных)" else "") { download(v) }
        }
    }
}
