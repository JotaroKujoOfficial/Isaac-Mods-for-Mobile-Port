package com.example.isaacmods

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Данные (пока тестовые, потом приходят с сервера) ----------
data class Mod(
    val id: Int,
    val name: String,
    val author: String,
    val description: String?,          // null = ИИ не нашёл точного описания, блок не показываем
    val tags: List<String>,
    val officialLatest: String?,       // последняя версия, если удалось узнать
    val foundVersions: List<String>,   // найденные версии, от новой к старой
    val source: String,
    val urls: Map<String, String> = emptyMap()   // версия -> https-ссылка на zip
) {
    val best get() = foundVersions.first()
    val isOutdated get() = officialLatest != null && best != officialLatest
}

val MODS = listOf(
    Mod(1, "Демо-мод: Новые предметы", "autor1", "Добавляет в игру 20 новых предметов и два новых артефакта.",
        listOf("предметы", "артефакты"), "2.1", listOf("2.1", "2.0", "1.5"), "example-site.org"),
    Mod(2, "Демо-мод: Персонаж", "autor2", "Добавляет нового играбельного персонажа с уникальными стартовыми предметами.",
        listOf("персонаж"), "1.3", listOf("1.2", "1.0"), "example-mods.net"),
    Mod(3, "Демо-мод: Боссы", "autor3", null,
        listOf("боссы", "предметы"), null, listOf("0.9"), "example-site.org")
)

// ---------- Каталог: catalog.json из твоего репозитория GitHub ----------
// ЗАМЕНИ на свою ссылку (репозиторий должен быть публичным)
const val CATALOG_URL = "https://raw.githubusercontent.com/ВАШ_НИК/ВАШ_РЕПО/main/catalog.json"

fun compareVersions(a: String, b: String): Int {
    val x = a.split(".", "-").map { it.toIntOrNull() ?: 0 }
    val y = b.split(".", "-").map { it.toIntOrNull() ?: 0 }
    for (i in 0 until maxOf(x.size, y.size)) {
        val c = x.getOrElse(i) { 0 }.compareTo(y.getOrElse(i) { 0 })
        if (c != 0) return c
    }
    return 0
}

fun loadCatalog(): List<Mod> {
    val text = URL(CATALOG_URL).openStream().bufferedReader().use { it.readText() }
    val arr = JSONObject(text).getJSONArray("mods")
    return (0 until arr.length()).mapNotNull { i ->
        val o = arr.getJSONObject(i)
        val vs = o.getJSONArray("versions")
        val pairs = (0 until vs.length()).map { j -> vs.getJSONObject(j).let { it.getString("version") to it.getString("url") } }
            .sortedWith(Comparator { a, b -> compareVersions(b.first, a.first) })
        val tg = o.optJSONArray("tags")
        if (pairs.isEmpty()) null else Mod(
            id = o.optInt("id", i),
            name = o.getString("name"),
            author = o.optString("author", "—"),
            description = if (o.isNull("description")) null else o.getString("description"),
            tags = if (tg == null) emptyList() else (0 until tg.length()).map { tg.getString(it).lowercase() },
            officialLatest = if (o.isNull("officialLatest")) null else o.getString("officialLatest"),
            foundVersions = pairs.map { it.first },
            source = o.optString("source", ""),
            urls = pairs.toMap()
        )
    }
}

// ---------- «ИИ-поиск» (заглушка: потом заменить запросом к серверу/ИИ) ----------
fun score(m: Mod, tokens: List<String>): Int = tokens.fold(0) { acc, t ->
    acc + (if (m.name.lowercase().contains(t)) 3 else 0) +
        (if (m.tags.any { it.contains(t) }) 2 else 0) +
        (if (m.description?.lowercase()?.contains(t) == true) 1 else 0)
}

// ---------- Свой стиль: тёмный, «кровавый», рубленые рамки ----------
val Bg = Color(0xFF1B1110); val PanelC = Color(0xFF2A1A18); val Edge = Color(0xFF5A3A33)
val Accent = Color(0xFFC0392B); val Ink = Color(0xFFF2E6D8); val Dim = Color(0xFFA89484); val Warn = Color(0xFFE0A030)
val Pixel = FontFamily.Monospace
val Blocky = RoundedCornerShape(2.dp)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = PanelC, onSurface = Ink, onBackground = Ink)) {
        var open by remember { mutableStateOf<Mod?>(null) }
        var mods by remember { mutableStateOf(MODS) }
        var status by remember { mutableStateOf<String?>(null) }
        LaunchedEffect(Unit) {
            try { mods = withContext(Dispatchers.IO) { loadCatalog() } }
            catch (e: Exception) { status = "Каталог не загрузился, показаны демо-моды" }
        }
        BackHandler(enabled = open != null) { open = null }
        Surface(Modifier.fillMaxSize(), color = Bg) {
            val m = open
            if (m == null) Catalog(mods, status) { open = it } else Detail(m) { open = null }
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    var mod = modifier.fillMaxWidth().border(3.dp, Edge, Blocky).background(PanelC)
    if (onClick != null) mod = mod.clickable(onClick = onClick)
    Column(mod.padding(12.dp), content = content)
}

@Composable
fun PixelButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.fillMaxWidth(), shape = Blocky, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)) {
        Text(text, fontFamily = Pixel, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ModCard(m: Mod, onOpen: (Mod) -> Unit) {
    Panel(onClick = { onOpen(m) }) {
        Text(m.name, color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("${m.author} · v${m.best}", color = Dim, fontFamily = Pixel, fontSize = 12.sp)
        Text(m.tags.joinToString(" · "), color = Dim, fontFamily = Pixel, fontSize = 12.sp)
        if (m.isOutdated) Text("⚠ не последняя версия", color = Warn, fontFamily = Pixel, fontSize = 12.sp)
    }
}

@Composable
fun Catalog(mods: List<Mod>, status: String?, onOpen: (Mod) -> Unit) {
    var q by remember { mutableStateOf("") }
    val tokens = q.lowercase().split(" ").filter { it.length > 1 }
    val found = if (tokens.isEmpty()) mods
        else mods.map { it to score(it, tokens) }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
    val similar = if (tokens.isEmpty() || found.isEmpty()) emptyList()
        else mods.filter { m -> m !in found && m.tags.any { it in found.first().tags } }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("МОДЫ ISAAC", color = Accent, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            if (status != null) Text(status, color = Warn, fontFamily = Pixel, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), shape = Blocky, singleLine = true,
                placeholder = { Text("Опиши, какой мод ищешь…", fontFamily = Pixel) })
        }
        items(found) { ModCard(it, onOpen) }
        if (tokens.isNotEmpty() && found.isEmpty()) item { Text("Ничего не нашлось", color = Dim, fontFamily = Pixel) }
        if (similar.isNotEmpty()) {
            item { Text("Похожие моды", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold) }
            items(similar) { ModCard(it, onOpen) }
        }
    }
}

@Composable
fun Detail(m: Mod, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var showOthers by remember { mutableStateOf(false) }
    fun download(v: String) {
        val url = m.urls[v]
        if (url == null || !url.startsWith("https://")) {
            Toast.makeText(ctx, "Для этой версии нет https-ссылки", Toast.LENGTH_SHORT).show(); return
        }
        val file = m.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_") + "_v$v.zip"
        val req = DownloadManager.Request(Uri.parse(url)).setTitle("${m.name} v$v")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, file)
        (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
        Toast.makeText(ctx, "Скачивание началось (папка Загрузки)", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TextButton(onBack) { Text("← Назад", color = Dim, fontFamily = Pixel) }
        Text(m.name, color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text("${m.author} · версия ${m.best} · источник: ${m.source}", color = Dim, fontFamily = Pixel, fontSize = 12.sp)
        if (m.isOutdated) Panel {
            Text("⚠ Это не последняя версия. Последняя: ${m.officialLatest}, но её найти не удалось. Показана максимальная найденная.",
                color = Warn, fontFamily = Pixel, fontSize = 13.sp)
        }
        m.description?.let { Panel { Text(it, color = Ink, fontFamily = Pixel, fontSize = 14.sp) } }
        PixelButton("Скачать v${m.best}") { download(m.best) }

        // Плашка внизу: другие версии
        Panel(onClick = { showOthers = !showOthers }) {
            Text(if (showOthers) "Скрыть другие версии ▲" else "Скачать другие версии ▼", color = Ink, fontFamily = Pixel, fontWeight = FontWeight.Bold)
        }
        if (showOthers) m.foundVersions.forEach { v ->
            PixelButton("v$v" + if (v == m.best) " (актуальная из найденных)" else "") { download(v) }
        }
    }
}
