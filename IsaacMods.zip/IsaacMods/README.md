# Моды Isaac (Android)
1. Залей проект в публичный репозиторий GitHub.
2. В MainActivity.kt замени CATALOG_URL на свою ссылку: https://raw.githubusercontent.com/НИК/РЕПО/main/catalog.json
3. Заполни catalog.json (моды, версии, https-ссылки на zip).
4. Actions -> Build APK -> Run workflow, скачай IsaacMods-debug-apk.
