# Моды Isaac (Android)
Каталог собирает crawler/crawl.py (GitHub Actions, раз в сутки) и кладёт в catalog.json.
APK собирается автоматически и выкладывается в Releases.
