import difflib, xml.etree.ElementTree as ET, io, zipfile, time, base64, json, os, re, sys, urllib.request, urllib.parse, datetime

TOKEN = os.environ.get("GITHUB_TOKEN")
OUT = sys.argv[1] if len(sys.argv) > 1 else "catalog.json"
QUERIES = ["topic:binding-of-isaac", "topic:isaac-mod", "topic:isaac-mods", "topic:binding-of-isaac-repentance", "topic:repentogon",
           "topic:tboi", "topic:tboi-mod", "topic:isaac-repentance", "topic:binding-of-isaac-mod", "topic:isaac-lua", "topic:isaac-api",
           "topic:binding-of-isaac-rebirth", "topic:binding-of-isaac-afterbirth", "topic:isaac-rebirth", "topic:isaac-afterbirth",
           "isaac mod in:name,description", "binding of isaac mod in:name,description", "repentance mod in:name,description",
           "isaac rebirth mod in:name,description", "isaac afterbirth mod in:name,description", "isaac items in:name,description",
           "isaac character in:name,description", "isaac boss in:name,description", "isaac lua in:name,description",
           "isaac resource pack in:name,description", "isaac sprites in:name,description", "isaac translation in:name,description",
           "isaac repentogon in:name,description", "tboi in:name,description", "isaac enemies in:name,description", "isaac skin in:name,description"]

def api(path):
    h = {"Accept": "application/vnd.github+json", "User-Agent": "isaac-mods-crawler"}
    if TOKEN:
        h["Authorization"] = "Bearer " + TOKEN
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request("https://api.github.com" + path, headers=h), timeout=30) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code in (403, 429) and attempt < 2:
                time.sleep(60)
                continue
            raise

def ver(tag):
    return re.sub(r"^[vV]", "", tag)

# прошлый каталог (кэш проверенных ссылок); учитывается только схема 2 = с проверкой файлов
old = {}
try:
    _o = json.load(open(OUT, encoding="utf-8"))
    if _o.get("schema") == 4:
        old = {m["id"]: m for m in _o["mods"]}
except Exception:
    pass

try:
    from PIL import Image
except ImportError:
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "pillow", "-q", "--break-system-packages"])
    try:
        from PIL import Image
    except ImportError:
        Image = None

META = {}  # url -> {"description": str|None, "icon": bytes}
ICON_DIR = os.path.join(os.path.dirname(os.path.abspath(OUT)), "icons")

def save_icon(mid, data):
    """Иконка мода из самого архива -> маленький png 128x128 в папке icons/."""
    if Image is None:
        return None
    try:
        im = Image.open(io.BytesIO(data)).convert("RGBA")
        im.thumbnail((128, 128))
        os.makedirs(ICON_DIR, exist_ok=True)
        im.save(os.path.join(ICON_DIR, "%d.png" % mid), optimize=True)
        return "icons/%d.png" % mid
    except Exception:
        return None

def zip_check(url):
    """Скачивает файл и проверяет: настоящий zip, не повреждён, внутри есть metadata.xml. Заодно берёт описание и иконку мода."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 IsaacModsCatalog/0.2"})
        with urllib.request.urlopen(req, timeout=90) as r:
            data = r.read(80 * 1024 * 1024 + 1)
        if len(data) < 500 or len(data) > 80 * 1024 * 1024:
            return False
        z = zipfile.ZipFile(io.BytesIO(data))
        if z.testzip() is not None:
            return False
        names = z.namelist()
        mds = [n for n in names if n.lower().endswith("metadata.xml")]
        if not mds:
            return False
        meta = {}
        try:
            d = (ET.fromstring(z.read(mds[0])).findtext("description") or "").strip()
            d = re.sub(r"\[/?[a-zA-Z*]+(=[^\]]*)?\]", " ", d)
            meta["description"] = re.sub(r"\s+", " ", d).strip()[:900] or None
        except Exception:
            pass
        icons = [n for n in names if re.search(r"(preview|icon|thumbnail|cover|logo)[^/]*\.(png|jpe?g)$", n.lower())
                 and n.count("/") <= 3 and z.getinfo(n).file_size < 3_000_000]
        if icons:
            icons.sort(key=lambda n: (n.count("/"), len(n)))
            meta["icon"] = z.read(icons[0])
        low = [n.lower() for n in names]
        meta["lua"] = any(n.endswith(".lua") for n in low)
        mc = set()
        if any("/sfx/" in n or "/music/" in n or n.endswith(".ogg") for n in low): mc.add("sounds")
        if any(n.endswith(".fnt") or "/font" in n for n in low): mc.add("fonts")
        if any("/languages/" in n or n.endswith("stringtable.sta") for n in low): mc.add("lang")
        if any("/gfx/" in n and n.endswith(".png") for n in low): mc.add("skins")
        if any(n.endswith("items.xml") for n in low): mc.add("items")
        if any(n.endswith("players.xml") for n in low): mc.add("characters")
        if any(n.endswith("entities2.xml") or "bossportrait" in n for n in low): mc.add("bosses")
        meta["cats"] = sorted(mc)
        META[url] = meta
        return True
    except Exception:
        return False

CAT_RX = {
    "items": r"\bitems?\b|collectible|trinket|pill|\bcards?\b|предмет",
    "characters": r"character|\bplayable\b|персонаж",
    "bosses": r"\bboss|enem(y|ies)|monster|босс|враг|монстр",
    "skins": r"\bskins?\b|reskin|retexture|texture|sprites?\b|costume|replac|скин|текстур|замен",
    "sounds": r"\bsounds?\b|music|\bsfx\b|soundtrack|\bost\b|звук|музык",
    "fonts": r"\bfonts?\b|шрифт",
    "lang": r"translat|localiz|\blanguage|русификат|перевод",
    "ui": r"\bui\b|interface|\bhud\b|интерфейс",
    "tools": r"\btools?\b|library|\bapi\b|utility|debug|console|утилит",
}

def cats_for(text, mcats):
    out = set(mcats or [])
    for c, rx in CAT_RX.items():
        if re.search(rx, text or "", re.I):
            out.add(c)
    return sorted(out)

def game_of(text):
    return "afterbirth" if re.search(r"afterbirth|rebirth|antibirth", text or "", re.I) and not re.search(r"repentance|repentogon", text or "", re.I) else "repentance"

def meta_for(mid, url):
    meta = META.get(url, {})
    prev = old.get(mid) or {}
    icon = prev.get("icon")
    if meta.get("icon"):
        icon = save_icon(mid, meta["icon"]) or icon
    return ((meta.get("description") or prev.get("description")), icon,
            (meta["cats"] if "cats" in meta else prev.get("categories", [])),
            (meta["lua"] if "lua" in meta else prev.get("lua")))

def keep_valid(versions, cached):
    cached_urls = {v["url"] for v in (cached or {}).get("versions", [])}
    out = []
    for v in versions:
        if v["url"] in cached_urls or zip_check(v["url"]):
            out.append(v)
        if len(out) >= 3:
            break
    return out

def ts_iso(x):
    try:
        return int(datetime.datetime.strptime(x, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=datetime.timezone.utc).timestamp())
    except Exception:
        return 0

repos = {}
for q in QUERIES:
    for page in range(1, 11):
        try:
            items = api("/search/repositories?q=%s&sort=stars&per_page=100&page=%d" % (urllib.parse.quote(q), page))["items"]
        except Exception as e:
            print("search failed", q, page, e)
            break
        for r in items:
            repos[r["full_name"]] = r
        if len(items) < 100:
            break
        time.sleep(2.5)
if not repos:
    sys.exit("no repos found, catalog not changed")

mods = []
for fn, r in repos.items():
    text = " ".join([r["name"], r.get("description") or ""] + r.get("topics", []))
    if not re.search(r"isaac|repentogon|rebirth|afterbirth|\btboi\b", text, re.I):
        continue
    try:
        rels = [x for x in api("/repos/%s/releases?per_page=6" % fn) if not x["draft"]]
    except Exception as e:
        print("releases failed", fn, e)
        continue
    versions, seen = [], set()
    if not rels:
        # мод без релизов: берём архив основной ветки, версия = дата последнего обновления
        versions = [{"version": (r.get("pushed_at") or "0")[:10], "url": "https://github.com/%s/archive/refs/heads/%s.zip" % (fn, r["default_branch"])}]
    for x in rels:
        v = ver(x["tag_name"])
        if v in seen:
            continue
        seen.add(v)
        zips = [a for a in x["assets"] if a["name"].lower().endswith(".zip") and a.get("size", 0) > 2000]
        url = zips[0]["browser_download_url"] if zips else "https://github.com/%s/archive/refs/tags/%s.zip" % (fn, urllib.parse.quote(x["tag_name"]))
        versions.append({"version": v, "url": url})
    if any("/archive/" in v["url"] for v in versions):
        # архив репозитория берём только если это настоящий мод Isaac (в корне есть metadata.xml)
        try:
            names = {x["name"].lower() for x in api("/repos/%s/contents/" % fn)}
        except Exception:
            names = set()
        if "metadata.xml" not in names:
            continue
    versions = keep_valid(versions, old.get(r["id"]))
    if not versions:
        continue
    stable = [x for x in rels if not x["prerelease"]]
    desc = (r.get("description") or "").strip()
    md, icon, mcats, mlua = meta_for(r["id"], versions[0]["url"])
    mods.append({
        "id": r["id"],
        "popularity": r.get("stargazers_count", 0),
        "updated": ts_iso(r.get("pushed_at")),
        "name": r["name"],
        "author": r["owner"]["login"],
        # описание вставляется только если в тексте источника точно речь об Isaac
        "_raw": md or desc,
        "description": md or (desc if re.search(r"isaac", desc, re.I) and len(desc) > 10 else None),
        "icon": icon,
        "_branch": r.get("default_branch", "main"),
        "categories": cats_for(text + " " + (md or ""), mcats), "lua": mlua, "game": game_of(text + " " + (md or "")),
        "tags": r.get("topics", []),
        "officialLatest": ver(stable[0]["tag_name"]) if stable else None,
        "source": "github.com/" + fn,
        "versions": versions,
    })


# ---- GameBanana (открытый API v11, прямое скачивание файлов) ----
def gb(path):
    req = urllib.request.Request("https://gamebanana.com/apiv11" + path, headers={"User-Agent": "IsaacModsCatalog/0.1"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)

GB_GAMES = {13178: "repentance"}  # The Binding of Isaac: Repentance
try:
    data = gb("/Util/Game/NameMatch?_sName=" + urllib.parse.quote("The Binding of Isaac"))
    for rec in (data.get("_aRecords", []) if isinstance(data, dict) else data):
        if "isaac" in str(rec.get("_sName", "")).lower():
            GB_GAMES[rec["_idRow"]] = "repentance" if "repentance" in str(rec.get("_sName", "")).lower() else "afterbirth"
except Exception as e:
    print("gamebanana game lookup failed", e)

gb_recs = {}
for gid, gname in GB_GAMES.items():
    for page in range(1, 41):
        try:
            d = gb("/Mod/Index?_aFilters%%5BGeneric_Game%%5D=%d&_nPage=%d&_nPerpage=50" % (gid, page))
        except Exception as e:
            print("gamebanana list failed", gid, page, e)
            break
        recs = d.get("_aRecords", [])
        for r in recs:
            r["_game"] = gname
            gb_recs[r["_idRow"]] = r
        if not recs or d.get("_aMetadata", {}).get("_bIsComplete"):
            break
        time.sleep(0.5)

for mid, r in gb_recs.items():
    try:
        d = gb("/Mod/%d?_csvProperties=_sName,_sVersion,_sDescription,_sText,_aFiles,_aSubmitter,_aPreviewMedia" % mid)
        files = [f for f in (d.get("_aFiles") or [])
                 if str(f.get("_sFile", "")).lower().endswith(".zip")
                 and int(f.get("_nFilesize") or 0) >= 2000
                 and str(f.get("_sDownloadUrl", "")).startswith("https://")]
        if not files:
            continue
        cands = [{"version": "", "url": f["_sDownloadUrl"]} for f in files]
        ts = r.get("_tsDateUpdated") or r.get("_tsDateAdded") or 0
        v = str(d.get("_sVersion") or "").strip() or time.strftime("%Y-%m-%d", time.gmtime(ts))
        vers = keep_valid([{"version": v, "url": c["url"]} for c in cands], old.get(2 * 10**8 + mid))[:1]
        if not vers:
            continue
        short = (d.get("_sDescription") or "").strip()
        md, icon, mcats, mlua = meta_for(2 * 10**8 + mid, vers[0]["url"])
        try:
            img = (d.get("_aPreviewMedia") or {}).get("_aImages", [{}])[0]
            gb_icon = img["_sBaseUrl"] + "/" + (img.get("_sFile220") or img.get("_sFile100") or img["_sFile"])
        except Exception:
            gb_icon = None
        mods.append({
            "id": 2 * 10**8 + mid,
            "popularity": int(r.get("_nLikeCount") or 0) * 5 + int(r.get("_nViewCount") or 0) // 100,
            "updated": int(ts),
            "name": d.get("_sName") or r.get("_sName") or "?",
            "author": (d.get("_aSubmitter") or r.get("_aSubmitter") or {}).get("_sName", "—"),
            "_raw": md or short or re.sub(r"<[^>]+>", " ", d.get("_sText") or "")[:2500],
            "description": md or short or None,
            "icon": gb_icon or icon,
            "categories": cats_for((d.get("_sName") or "") + " " + (md or short), mcats), "lua": mlua, "game": r.get("_game", "repentance"),
            "tags": [], "officialLatest": v, "source": "gamebanana.com",
            "versions": vers,
        })
    except Exception as e:
        print("gamebanana mod failed", mid, e)
    time.sleep(0.2)

# ---- Nexus Mods (официальный API, нужен ключ NEXUS_API_KEY; файлы там качаются только на сайте) ----
NEXUS = os.environ.get("NEXUS_API_KEY")
if NEXUS:
    for lst in ("trending", "latest_added", "latest_updated"):
        try:
            req = urllib.request.Request(
                "https://api.nexusmods.com/v1/games/thebindingofisaacrebirth/mods/%s.json" % lst,
                headers={"apikey": NEXUS, "Application-Name": "IsaacModsCatalog", "Application-Version": "0.1", "User-Agent": "isaac-mods-crawler"})
            for m in json.load(urllib.request.urlopen(req, timeout=30)):
                mid = 10**8 + m["mod_id"]
                if any(x["id"] == mid for x in mods) or not m.get("available", True):
                    continue
                v = str(m.get("version") or "?")
                summ = (m.get("summary") or "").strip()
                mods.append({
                    "id": mid, "name": m["name"], "author": m.get("author", "—"),
                    "popularity": 500 if lst == "trending" else 0, "updated": int(m.get("updated_timestamp") or 0),
                    "_raw": summ, "description": summ or None, "icon": m.get("picture_url"), "categories": cats_for(m["name"] + " " + summ, []), "lua": None, "game": game_of(m["name"] + " " + summ), "tags": [],
                    "officialLatest": v, "source": "nexusmods.com", "pageOnly": True,
                    "versions": [{"version": v, "url": "https://www.nexusmods.com/thebindingofisaacrebirth/mods/%d" % m["mod_id"]}],
                })
        except Exception as e:
            print("nexus failed", lst, e)

# ---- Иконки: если в самом моде картинки нет, ищем в других источниках по названию ----
def readme_image(fn, branch):
    try:
        t = base64.b64decode(api("/repos/%s/readme" % fn)["content"]).decode("utf-8", "ignore")
    except Exception:
        return None
    for mt in re.finditer(r'!\[[^\]]*\]\(([^)\s]+)[^)]*\)|<img[^>]+src=["\']([^"\']+)["\']', t):
        u = mt.group(1) or mt.group(2)
        if re.search(r"shields\.io|badge|travis|/workflows/|\.svg(\?|$)", u, re.I):
            continue
        if not re.search(r"\.(png|jpe?g|gif|webp)(\?|$)", u, re.I) and "githubusercontent" not in u:
            continue
        if u.startswith("//"):
            u = "https:" + u
        if not u.startswith("http"):
            u = "https://raw.githubusercontent.com/%s/%s/%s" % (fn, branch, u.lstrip("./"))
        return u
    return None

def gb_icon_by_name(name):
    try:
        d = gb("/Util/Search/Results?_sSearchString=%s&_sModelName=Mod&_idGameRow=13178" % urllib.parse.quote(name))
        for rec in d.get("_aRecords", [])[:5]:
            if difflib.SequenceMatcher(None, name.lower(), str(rec.get("_sName", "")).lower()).ratio() < 0.85:
                continue
            img = (rec.get("_aPreviewMedia") or {}).get("_aImages", [{}])[0]
            return img["_sBaseUrl"] + "/" + (img.get("_sFile220") or img.get("_sFile100") or img["_sFile"])
    except Exception:
        pass
    return None

lookups = 0
for m in mods:
    if m.get("icon") or lookups >= 250:
        continue
    lookups += 1
    ic = None
    if m["source"].startswith("github.com/"):
        ic = readme_image(m["source"][11:], m.get("_branch", "main"))
    m["icon"] = ic or gb_icon_by_name(m["name"])

# ---- ИИ: описание и ключевые слова для поиска (нужен ключ ANTHROPIC_API_KEY) ----
KEY = os.environ.get("ANTHROPIC_API_KEY")
PROMPT = ("Ниже текст из источника о моде «%s» для The Binding of Isaac. Верни ТОЛЬКО JSON вида "
          '{"description": ..., "keywords": [...], "categories": [...]}. '
          "description: перевод описания на русский (короткий текст переведи целиком, длинный перескажи до 500 символов), строго по тексту, без выдумок. "
          "Игровой и программистский сленг, профессиональные термины (Lua, API, mod, boss, item и т.п.), названия предметов, персонажей, врагов, модов, ники и имена собственные "
          "НЕ переводи: оставляй как есть или пиши русскими буквами. Обычные слова переводи естественно, как живой человек. "
          "Если из текста не ясно, что делает именно этот мод, верни null. "
          "keywords: до 12 слов на русском и английском, по которым мод могут искать. "
          "categories: подходящие из списка items, characters, bosses, skins, sounds, fonts, lang, ui, tools.\n\nТекст:\n%s")

def ask_ai(name, text):
    body = json.dumps({"model": "claude-haiku-5-5", "max_tokens": 900,
                       "messages": [{"role": "user", "content": PROMPT % (name, text[:3000])}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    out = json.load(urllib.request.urlopen(req, timeout=60))["content"][0]["text"]
    return json.loads(re.search(r"\{.*\}", out, re.S).group(0))

calls = 0
for m in mods:
    o = old.get(m["id"])
    if o and o.get("keywords"):
        m["keywords"], m["description"] = o["keywords"], o.get("description")
        continue
    if not KEY or calls >= 300:
        continue
    text = m.get("_raw") or ""
    if m["source"].startswith("github.com/") and len(text) < 200:
        try:
            text += "\n" + base64.b64decode(api("/repos/%s/readme" % m["source"][11:])["content"]).decode("utf-8", "ignore")[:2500]
        except Exception:
            pass
    if not text.strip():
        continue
    try:
        calls += 1
        r = ask_ai(m["name"], text)
        m["description"] = r.get("description") or None
        m["keywords"] = [str(k).lower() for k in r.get("keywords", [])][:12]
        m["categories"] = sorted(set(m.get("categories", [])) | {c for c in r.get("categories", []) if c in CAT_RX})
    except Exception as e:
        print("ai failed", m["name"], e)
for m in mods:
    m.pop("_raw", None)
    m.pop("_branch", None)

json.dump({"schema": 4, "updated": datetime.datetime.utcnow().isoformat() + "Z", "mods": mods}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("mods:", len(mods))
