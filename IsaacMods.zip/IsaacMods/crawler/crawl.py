import time, base64, json, os, re, sys, urllib.request, urllib.parse, datetime

TOKEN = os.environ.get("GITHUB_TOKEN")
OUT = sys.argv[1] if len(sys.argv) > 1 else "catalog.json"
QUERIES = ["topic:binding-of-isaac", "topic:isaac-mod", "topic:binding-of-isaac-repentance", "topic:repentogon",
           "isaac mod in:name,description", "binding of isaac mod in:name,description", "repentance mod in:name,description",
           "isaac rebirth mod in:name,description", "isaac afterbirth mod in:name,description", "isaac items mod in:name,description",
           "isaac character mod in:name,description"]

def api(path):
    h = {"Accept": "application/vnd.github+json", "User-Agent": "isaac-mods-crawler"}
    if TOKEN:
        h["Authorization"] = "Bearer " + TOKEN
    with urllib.request.urlopen(urllib.request.Request("https://api.github.com" + path, headers=h), timeout=30) as r:
        return json.load(r)

def ver(tag):
    return re.sub(r"^[vV]", "", tag)

def ts_iso(x):
    try:
        return int(datetime.datetime.strptime(x, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=datetime.timezone.utc).timestamp())
    except Exception:
        return 0

repos = {}
for q in QUERIES:
    for page in range(1, 11):
        try:
            items = api("/search/repositories?q=%s&sort=stars&per_page=100&page=%d" % (urllib.parse.quote(q), page))["items"]
        except Exception as e:
            print("search failed", q, page, e)
            break
        for r in items:
            repos[r["full_name"]] = r
        if len(items) < 100:
            break
        time.sleep(2.5)
if not repos:
    sys.exit("no repos found, catalog not changed")

mods = []
for fn, r in repos.items():
    text = " ".join([r["name"], r.get("description") or ""] + r.get("topics", []))
    if not re.search(r"\bmods?\b|-mod\b|mod-", text, re.I) or not re.search(r"isaac|repentogon|rebirth|afterbirth", text, re.I):
        continue
    try:
        rels = [x for x in api("/repos/%s/releases?per_page=6" % fn) if not x["draft"]]
    except Exception as e:
        print("releases failed", fn, e)
        continue
    versions, seen = [], set()
    if not rels:
        # мод без релизов: берём архив основной ветки, версия = дата последнего обновления
        versions = [{"version": (r.get("pushed_at") or "0")[:10], "url": "https://github.com/%s/archive/refs/heads/%s.zip" % (fn, r["default_branch"])}]
    for x in rels:
        v = ver(x["tag_name"])
        if v in seen:
            continue
        seen.add(v)
        zips = [a for a in x["assets"] if a["name"].lower().endswith(".zip")]
        url = zips[0]["browser_download_url"] if zips else "https://github.com/%s/archive/refs/tags/%s.zip" % (fn, urllib.parse.quote(x["tag_name"]))
        versions.append({"version": v, "url": url})
    stable = [x for x in rels if not x["prerelease"]]
    desc = (r.get("description") or "").strip()
    mods.append({
        "id": r["id"],
        "popularity": r.get("stargazers_count", 0),
        "updated": ts_iso(r.get("pushed_at")),
        "name": r["name"],
        "author": r["owner"]["login"],
        # описание вставляется только если в тексте источника точно речь об Isaac
        "_raw": desc,
        "description": desc if re.search(r"isaac", desc, re.I) and len(desc) > 10 else None,
        "tags": r.get("topics", []),
        "officialLatest": ver(stable[0]["tag_name"]) if stable else None,
        "source": "github.com/" + fn,
        "versions": versions,
    })


# ---- GameBanana (открытый API v11, прямое скачивание файлов) ----
def gb(path):
    req = urllib.request.Request("https://gamebanana.com/apiv11" + path, headers={"User-Agent": "IsaacModsCatalog/0.1"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)

GB_GAMES = {13178}  # The Binding of Isaac: Repentance
try:
    data = gb("/Util/Game/NameMatch?_sName=" + urllib.parse.quote("The Binding of Isaac"))
    for rec in (data.get("_aRecords", []) if isinstance(data, dict) else data):
        if "isaac" in str(rec.get("_sName", "")).lower():
            GB_GAMES.add(rec["_idRow"])
except Exception as e:
    print("gamebanana game lookup failed", e)

gb_recs = {}
for gid in GB_GAMES:
    for page in range(1, 41):
        try:
            d = gb("/Mod/Index?_aFilters%%5BGeneric_Game%%5D=%d&_nPage=%d&_nPerpage=50" % (gid, page))
        except Exception as e:
            print("gamebanana list failed", gid, page, e)
            break
        recs = d.get("_aRecords", [])
        for r in recs:
            gb_recs[r["_idRow"]] = r
        if not recs or d.get("_aMetadata", {}).get("_bIsComplete"):
            break
        time.sleep(0.5)

for mid, r in gb_recs.items():
    try:
        d = gb("/Mod/%d?_csvProperties=_sName,_sVersion,_sDescription,_sText,_aFiles,_aSubmitter" % mid)
        files = d.get("_aFiles") or []
        if not files or not str(files[0].get("_sDownloadUrl", "")).startswith("https://"):
            continue
        ts = r.get("_tsDateUpdated") or r.get("_tsDateAdded") or 0
        v = str(d.get("_sVersion") or "").strip() or time.strftime("%Y-%m-%d", time.gmtime(ts))
        short = (d.get("_sDescription") or "").strip()
        mods.append({
            "id": 2 * 10**8 + mid,
            "popularity": int(r.get("_nLikeCount") or 0) * 5 + int(r.get("_nViewCount") or 0) // 100,
            "updated": int(ts),
            "name": d.get("_sName") or r.get("_sName") or "?",
            "author": (d.get("_aSubmitter") or r.get("_aSubmitter") or {}).get("_sName", "—"),
            "_raw": short or re.sub(r"<[^>]+>", " ", d.get("_sText") or "")[:2500],
            "description": short or None,
            "tags": [], "officialLatest": v, "source": "gamebanana.com",
            "versions": [{"version": v, "url": files[0]["_sDownloadUrl"]}],
        })
    except Exception as e:
        print("gamebanana mod failed", mid, e)
    time.sleep(0.2)

# ---- Nexus Mods (официальный API, нужен ключ NEXUS_API_KEY; файлы там качаются только на сайте) ----
NEXUS = os.environ.get("NEXUS_API_KEY")
if NEXUS:
    for lst in ("trending", "latest_added", "latest_updated"):
        try:
            req = urllib.request.Request(
                "https://api.nexusmods.com/v1/games/thebindingofisaacrebirth/mods/%s.json" % lst,
                headers={"apikey": NEXUS, "Application-Name": "IsaacModsCatalog", "Application-Version": "0.1", "User-Agent": "isaac-mods-crawler"})
            for m in json.load(urllib.request.urlopen(req, timeout=30)):
                mid = 10**8 + m["mod_id"]
                if any(x["id"] == mid for x in mods) or not m.get("available", True):
                    continue
                v = str(m.get("version") or "?")
                summ = (m.get("summary") or "").strip()
                mods.append({
                    "id": mid, "name": m["name"], "author": m.get("author", "—"),
                    "popularity": 500 if lst == "trending" else 0, "updated": int(m.get("updated_timestamp") or 0),
                    "_raw": summ, "description": summ or None, "tags": [],
                    "officialLatest": v, "source": "nexusmods.com", "pageOnly": True,
                    "versions": [{"version": v, "url": "https://www.nexusmods.com/thebindingofisaacrebirth/mods/%d" % m["mod_id"]}],
                })
        except Exception as e:
            print("nexus failed", lst, e)

# ---- ИИ: описание и ключевые слова для поиска (нужен ключ ANTHROPIC_API_KEY) ----
KEY = os.environ.get("ANTHROPIC_API_KEY")
PROMPT = ("Ниже текст из источника о моде «%s» для The Binding of Isaac. Верни ТОЛЬКО JSON вида "
          '{"description": ..., "keywords": [...]}. description: 1-2 предложения по-русски о том, что делает мод, '
          "строго на основании текста; если из текста не ясно, что делает именно этот мод, верни null. "
          "keywords: до 12 слов на русском и английском (предметы, персонажи, боссы, интерфейс, сложность и т.п.), "
          "по которым человек может искать этот мод.\n\nТекст:\n%s")

def ask_ai(name, text):
    body = json.dumps({"model": "claude-haiku-5-5", "max_tokens": 500,
                       "messages": [{"role": "user", "content": PROMPT % (name, text[:3000])}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    out = json.load(urllib.request.urlopen(req, timeout=60))["content"][0]["text"]
    return json.loads(re.search(r"\{.*\}", out, re.S).group(0))

old = {}
try:
    old = {m["id"]: m for m in json.load(open(OUT, encoding="utf-8"))["mods"]}
except Exception:
    pass
calls = 0
for m in mods:
    o = old.get(m["id"])
    if o and o.get("keywords"):
        m["keywords"], m["description"] = o["keywords"], o.get("description")
        continue
    if not KEY or calls >= 300:
        continue
    text = m.get("_raw") or ""
    if m["source"].startswith("github.com/") and len(text) < 200:
        try:
            text += "\n" + base64.b64decode(api("/repos/%s/readme" % m["source"][11:])["content"]).decode("utf-8", "ignore")[:2500]
        except Exception:
            pass
    if not text.strip():
        continue
    try:
        calls += 1
        r = ask_ai(m["name"], text)
        m["description"] = r.get("description") or None
        m["keywords"] = [str(k).lower() for k in r.get("keywords", [])][:12]
    except Exception as e:
        print("ai failed", m["name"], e)
for m in mods:
    m.pop("_raw", None)

json.dump({"updated": datetime.datetime.utcnow().isoformat() + "Z", "mods": mods}, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("mods:", len(mods))
